<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8"> </meta>
        <title> Register Account </title>
        <style> 
            body {
                padding: 0;
                margin: 0;
                font-family: 'RadikalW03-Regular';
                text-align: center;
                transition: 0.5s;
                background-image: url('https://api.nomadstudio.com/images/_1200x630_crop_center-center_82_none/WEBSITE_PROJECT_TILES_PL-169.jpg?mtime=1593605778');
                background-repeat: no-repeat;
                background-attachment: fixed;
                background-size: cover;
            }

            .card {
                box-shadow: 2px 2px 2px 1px rgba(0, 0, 0, 0.2);
                border-radius:30px;
                background-color: white;
                border: 0;
                padding: 5px;
                left: 38%;
                top: 5%;
                width: 20%;
                position: relative;
                transition: 0.3s;
            }

            .card:hover {
                background-image: url('https://resources.premierleague.com/photos/2020/12/02/ca403c92-db70-48ac-91e2-0f2f18277133/PageHeader_RainbowLaces.png?width=1600&height=600');
                transition: 0.3s;
                color: white;
            }

            form {
                width: 20%;
                position: relative;
                background-color: #F3900F;
                color: #420C49;
                transition: 0.3s;
                left: 36%;
                margin: 30px;
                padding: 10px;
                border: 0;
                border-radius: 40px;
                box-shadow: 5px 5px 5px 1px rgba(0, 0, 0, 0.2);
            }

            form > input {
                border: 0px solid;
                border-radius: 10px;
                margin: 10px;
                padding: 10px;
            }

            form > input:active {
                border: 0px solid;
                border-radius: 10px;
            }

            form > button {
                border: 0px solid;
                border-radius: 10px;
                margin: 10px;
                padding: 10px;
                transition: 0.3s;
            }

            form > img {
                width:150px;
                margin: 10px;
            }
            form > button:hover {
                color: #420C49;
                background-color: #F3900F;
                transition: 0.3;
            } 

            form:hover {
                transition: 0.3s;
                box-shadow: 5px 5px 5px 1px rgba(0, 0, 0, 0.2);
                color: white;
                background-color: #420C49;
                width: 40%;
                left: 26%;
            }

            a {
              color: white;
            }

            a:link {
                
            }

            a:hover {
                color: #F3900F;
            }

            @media screen {
                
            }

            /* ________________________________  */
            .footer-title {
              background-color: #420C49;
              padding: 20px;
              color: white;
              bottom: 0;
              left: 0;
              right: 0;
            }

        </style>
    </head>
    <body>
            
        <form method="POST" action="register" id="register" name="register"> 
            <img src="<?= BASEURL;?>/assets/img/icon.png"> <br>
            <h2> Register </h2>
            <label for="email"> Email </label> <br>
            <input type="email" name="email" id="email" placeholder="Email"> <br>
            <label for="username"> Username </label> <br>
            <input type="text" name="username" id="username" placeholder="Username"> <br>
            <label for="club"> Favourite Club </label> <br>
            <input type="text" name="club" id="club" placeholder="Club"> <br>
            <label for="favplayer"> Favourite Player </label> <br>
            <input type="text" name="favplayer" id="favplayer" placeholder="Player"> <br>
            <label for="password"> Password </label> <br>
            <input type="password" name="password" id="password" placeholder="Password" required> <br>
            <input type="checkbox" name="agree" id="agree"> I agree to follow Terms & Policy </checkbox> <br>
            <button type="submit" name="register" id="register"> Register </button>
            <br>
            <p> Already have account? Login now! <a href="login"> >> </a> </p>
        </form>

        <footer>
            <div class="footer-title"> Halcyon.inc | Copyright 2021, All Rights Reserved. </div>
        </footer>
    </body>
</html>