<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Main Menu </title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
    <style> 
        .bg-about {
            background: url('https://miro.medium.com/max/2000/1*d0swlG4YyQIt0CNNO-toYQ.jpeg');
            height: 750px;
            width: 100%;
            object-fit: cover;
            margin: -20px -15px;
            padding: 0;
            background-size: cover;
            background-repeat: no-repeat;
            padding-left: 70px;
      }

      .bg-about2 {
            background: url('https://exhibitionmakers.com/wp-content/uploads/2018/03/The-Design-and-Decoration-of-Exhibition-Stands-5.jpg');
            height: 300px;
            width: 100%;
            object-fit: cover;
            margin: -20px -15px;
            padding: 0;
            background-size: cover;
            background-repeat: no-repeat;
            padding-left: 70px;
      }

      .maintop {
        padding: 60px 0 20px 0px;
      }

      .mainbttm {
          padding-bottom: 60px;
      }

      .text-title {
        text-align: left;
        color: black;
        background-color: #FFFFFF;
        width: 400px;
        height: 155px;
        font-family: 'RadikalW03-Bold';
        padding-left: 20px;
        font-size: 60px;
      }

      .text-title2 {
        text-align: left;
        color: black;
        height: 155px;
        font-family: 'RadikalW03-Bold';
        padding-left: 20px;
        font-size: 50px;
        padding-top: 30px;
      }

      .subtext-title {
        text-align: left;
        color: black;
        background-color: #FFFFFF;
        width: 400px;
        height: 45px;
        font-family: 'RadikalW03-Bold';
        padding-left: 20px;
        font-size: 30px;
      }

      .classified-text {
          color: black;
          width: 50%;
          background-color: #FFFFFF;
          padding: 20px;
      }

      .length-this {
          width: 700px;
      }

      .topit {
        padding-top: 40px;
      }

      .hei1 {
        object-fit: cover;
        height: 350px;
        width: 350px;
        padding: 5px;
        background-size: cover;
        background-repeat: no-repeat;
        transition: 0.7s;
      }

      .hei1:hover {
        height: 320px;
        width: 320px;
        transition: 0.7s;
      }

      .link-none a {
          text-decoration: none;
          color: black;
      }

      .move-right {
          padding-top: 100px;
          padding-left: 25px;
      }
    </style>
</head>
  <body>
    <header>
      <div class="container">
        <div class="header-left">
          <a href="mainmenu"> <img class="logo" src="../assets/img/icon.png" href="mainmenu"> </a>
        </div>
        <!-- Add a menu icon here -->
  
        <div class="header-right">
          <a href="designmenu">What's new?</a>
          <a href="about"> About us </a>
          <a href="#designtoday">Current design</a>
          <a href="comment"> Feedback</a>
          <a href="logout" class="logout">Log out</a>
        </div>
      </div>
    </header>

  <h1 style="text-align:center; font-family: RadikalW03-Bold; font-size: 50px;" class="subtitle-pad" id="designtoday"> Today's Design </h1>
  <div class="card-group content">
    <div class="card">
      <img class="card-img-top img-centering-size" src="https://cdn.pixabay.com/photo/2020/05/21/08/31/lion-5199769_1280.jpg" alt="Card image cap">
      <div class="card-body">
        <h5 class="card-title"> Carolina </h5>
        <p class="card-text"> Designed by: Freepik. <br> Including: minimalist abstract, concepted gradient colors such red, white, and black. </p>
        <p class="card-text"><small class="text-muted"> Rating 4.5/5 </small></p>
      </div>
    </div>
    <div class="card">
      <img class="card-img-top img-centering-size" src="https://assets-global.website-files.com/5e469aaf314e562ff1146d3f/5feb0f4527cc9976b63dd88c_big-bang-mockup.png" alt="Card image cap">
      <div class="card-body">
        <h5 class="card-title"> Yellow Coffee </h5>
        <p class="card-text"> Designed by: Tierre Laurent. <br> Including: simple style inspired by mashup yellow and chocolate style, combined with a single variant </p>
        <p class="card-text"><small class="text-muted"> Rating 4/5 </small></p>
      </div>
    </div>
    <div class="card">
      <img class="card-img-top img-centering-size" src="https://wallpaper.dog/large/20449397.jpg" alt="Card image cap">
      <div class="card-body">
        <h5 class="card-title"> Outline World </h5>
        <p class="card-text"> Designed by: Dimitri Patrenko. <br> Including: no decoration + full concentration filter with a single semi-BnW style</p>
        <p class="card-text"><small class="text-muted"> Rating 4.2/5 </small></p>
      </div>
    </div>
    <div class="card">
      <img class="card-img-top img-centering-size" src="https://images2.alphacoders.com/585/58562.jpg" alt="Card image cap">
      <div class="card-body">
        <h5 class="card-title"> Sebisu </h5>
        <p class="card-text"> Designed by: Shakirra Bentsu. <br> Including: collaboration between latte & chocolate style, provided with a single typography using traditional font </p>
        <p class="card-text"><small class="text-muted">Rating 4.1/5 </small></p>
      </div>
    </div>
  </div>


  <div class="topit container2">
      <table>
        <tr>
          <th>
            <img src="https://i.pinimg.com/originals/10/df/66/10df66ac38572407d40d6112f56a9b74.jpg" class="hei1">
            <img src="https://i.ytimg.com/vi/QmuL6DmH59Y/maxresdefault.jpg" class="hei1">
            <img src="https://i.pinimg.com/originals/c1/8f/e4/c18fe4c2a0921a5119ac22c642f96884.jpg" class="hei1">
            <img src="https://i.pinimg.com/1200x/3e/b1/19/3eb119e8f3f25f1f2fe4d18502754ea0.jpg" class="hei1">
          </th>
          <th>
            <h1 style="font-family: RadikalW03-Bold; font-size: 50px;"> Recommended <br> for Beginner </h1>
            <br> 
                <ul class="link-none">
                    <li> <a href="https://i.pinimg.com/originals/10/df/66/10df66ac38572407d40d6112f56a9b74.jpg"> Clip of ignored everyday </a> </li>
                    <li> <a href="https://i.ytimg.com/vi/QmuL6DmH59Y/maxresdefault.jpg"> Story of Persane </a> </li>
                    <li> <a href="https://i.pinimg.com/originals/c1/8f/e4/c18fe4c2a0921a5119ac22c642f96884.jpg"> Rite: The Directory </a> </li>
                    <li> <a href="https://i.pinimg.com/1200x/3e/b1/19/3eb119e8f3f25f1f2fe4d18502754ea0.jpg"> Zeka: The Glasses </a> </li>
                </ul>
          </th>
        </tr>
      </table>
  </div>


  <div class="maintop">
      <div class="bg-about"> <br>
          <h2 class="text-title"> Meet Our Designer </h2>
          <p class="subtext-title"> Budi Tanrim</p>
          <div id="carouselExampleControls" class="carousel slide length-this" data-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active classified-text">
                    <h4> Hi, what are you busy with? </h4>
                    <p> "Hello, generally speaking — currently busy with preparation for Canada, although the preparation is not done every day but it is quite time-consuming.
                        Besides that, I'm also busy making icons on Budicon." </p>
                </div>
                <div class="carousel-item classified-text">
                    <h4> Can you tell us a little about how you started your career in Bud's design world? </h4>
                    <p>  "Before I graduated, I started to focus on strengthening my portfolio and doing many pitches to several clients. Although often rejected and not considered — I was lucky enough, because one of the startups in San Francisco, Zerply decided to put me in a fairly small team. I learned about startup business and had the opportunity to go to the US for an interview with them."</p>
                </div>
                <div class="carousel-item classified-text">
                    <h4> Can you tell us what is your secret or how do you master many skills? </h4>
                    <p> "Well, the way may start with a sense of love and passion. This is an important key, if there is no passion, it will be very difficult to want to learn a topic. For example, I personally really like hand-lettering, editorial illustrations, UI/UX, and icons." </p>
                </div>
                <div class="carousel-item classified-text">
                    <h4> Can you explain a little about what is Budicon? What are the future plans? </h4>
                    <p> "Budicon is a side project that is quite successful, in a sense — it makes a good profit and is also used by designers and agencies worldwide.
                    Future plans will certainly continue to process icon sets with different styles.
                    After that, I plan to provide free tutorials on my blog in the form of videos for other designers who want to learn icon design." </p>
                </div>
                <div class="carousel-item classified-text">
                    <h4> Have you ever felt bored with the work you are currently doing? What do you usually do when you're bored? How do you handle it? </h4>
                    <p> "Well, this is one of the advantages of being a multidisciplinary designer, I can switch fields at any time when I'm bored.
                            For example this year, I was quite bored with the world of product design, so I decided to switch to Illustration and Icon.
                            Besides, being a multidisciplinary designer, I always learn new things and become a beginner again." </p>
                </div>
                <div class="carousel-item classified-text">
                    <h4> Can you tell us about your creative process? Where do you get your inspiration from? </h4>
                    <p> "When it comes to inspiration from other designers, I really like exploring pinterest, because it introduces me to really random designers/artists.
                        Sometimes, I use dribbble, but dribbble is more limited because the players are more or less the same, which is 5 years old and has memorized their work :) While on Pinterest I can find new inspiration." </p>
                </div>
                <div class="carousel-item classified-text">
                    <h4> Is there an influence or advice that has made a Budi until now? </h4>
                    <p> "I think I always want to master new skills, I'm never satisfied with what I'm good at." </p>
                </div>
                <div class="carousel-item classified-text">
                    <h4> In your entire career, what is the most difficult situation you have been in? </h4>
                    <p> "It's quite scary, because for example to build an icon design portfolio, I have to focus on icons and reject many UI design projects.
                        If I accept a UI design project, I don't have time to build a portfolio and practice.
                        Fortunately, my decision paid off, until it was trusted by Yahoo to redesign their icon, and also trusted by Marvel app to make the icon." </p>
                </div>
                <div class="carousel-item classified-text">
                    <h4> Can you share tips for friends who want to work abroad like you? </h4>
                    <p> "My tips, make a strong study case and portfolio so that the company can really be sure to hire you.
                        The portfolio on Dribbble is okay and legal, but the company won't be sure to hire you if it's only based on that.
                        What is a strong case study? In essence, show that you can identify problems and solve problems with smart solutions.
                        Is making a cool design wrong? No, it's not wrong at all — as long as you have to consider usability as well." </p>
                </div>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
            </div>
      </div>
    </div>


  <h1 style="text-align:center; font-family: RadikalW03-Bold; font-size: 50px;" class="subtitle-pad" id="designtoday"> Design of the Year </h1>
  <div class="card-group content">
    <div class="card">
      <img class="card-img-top" src="https://image.freepik.com/free-vector/minimalist-pink-social-media-instagram-feed-post-banner-template_74058-383.jpg" alt="Card image cap">
      <div class="card-body">
        <h5 class="card-title"> Carolina </h5>
        <p class="card-text"> Designed by: Freepik. <br> Including: minimalist abstract, concepted gradient colors such red, white, and black. </p>
        <p class="card-text"><small class="text-muted"> Rating 4.5/5 </small></p>
      </div>
    </div>
    <div class="card">
      <img class="card-img-top" src="https://graphicriver.img.customer.envatousercontent.com/files/312933458/grapchicriver.jpg?auto=compress%2Cformat&fit=crop&crop=top&w=590&h=590&s=8a7084bfa76f12b8a65166eee0a13bf4" alt="Card image cap">
      <div class="card-body">
        <h5 class="card-title"> Yellow Coffee </h5>
        <p class="card-text"> Designed by: Tierre Laurent. <br> Including: simple style inspired by mashup yellow and chocolate style, combined with a single variant </p>
        <p class="card-text"><small class="text-muted"> Rating 4/5 </small></p>
      </div>
    </div>
    <div class="card">
      <img class="card-img-top" src="https://nataliegisborne.com/wp-content/uploads/2-4.jpg" alt="Card image cap">
      <div class="card-body">
        <h5 class="card-title"> Outline World </h5>
        <p class="card-text"> Designed by: Dimitri Patrenko. <br> Including: no decoration + full concentration filter with a single semi-BnW style</p>
        <p class="card-text"><small class="text-muted"> Rating 4.2/5 </small></p>
      </div>
    </div>
    <div class="card">
      <img class="card-img-top" src="https://cf.shopee.co.id/file/ed450c9f61d71cc2a585e41c8b163e2f" alt="Card image cap">
      <div class="card-body">
        <h5 class="card-title"> Sebisu </h5>
        <p class="card-text"> Designed by: Shakirra Bentsu. <br> Including: collaboration between latte & chocolate style, provided with a single typography using traditional font </p>
        <p class="card-text"><small class="text-muted">Rating 4.1/5 </small></p>
      </div>
    </div>
  </div>



    <div class="maintop mainbttm">
      <div class="bg-about2">
          <h2 class="text-title2"> Want to be shown at Halcyon? <br> Become the Halcyonier! </h2>
          <a href="subscribe" class="move-right"> <button class="join-us2"> Click here! </button> </a>
      </div>
    </div>



    <footer>
      <div class="footer-title"> Halcyon.inc | Copyright 2021, All Rights Reserved. </div>
  </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>
