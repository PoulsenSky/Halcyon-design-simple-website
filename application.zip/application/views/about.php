<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> About us </title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">


    <style>

      .bg-about {
        background: url('https://wallpaperaccess.com/full/1567665.png');
        height: 300px;
        width: 100%;
        object-fit: cover;
        margin: -20px -15px;
        padding: 0;
      }

      .text-title {
        text-align: right;
        color: white;
        font-family: 'RadikalW03-Bold';
        padding-top: 90px;
        padding-right: 120px;
        font-size: 100px;
      }

      .intro {
        padding: 40px;
      }

      .quote-italy {
        font-style: italic;
        text-align: center;
      }

      .ppicture {
        width: 360px;
        transition: 1.5s;
      }

      .ppicture:hover {
        width:400px;
        transition: 1.5s;
      }

      .table-info-profile {
        width: 90%;
        position: relative;
        background-color: #520E66;
        color: white;
        transition: 0.3s;
        margin: 30px;
        padding: 10px;
        border: 0;
        box-shadow: 5px 5px 5px 1px rgba(0, 0, 0, 0.2);
      }

    </style>
  </head>
  <body>
    <header>
      <div class="container">
        <div class="header-left">
          <a href="mainmenu"> <img class="logo" src="../assets/img/icon.png"> </a>
        </div>
        <!-- Add a menu icon here -->
  
        <div class="header-right">
          <a href="designmenu">What's new?</a>
          <a href="about"> About us </a>
          <a href="comment"> Feedback</a>
          <a href="login" class="logout">Log out</a>
        </div>
      </div>
    </header>

  <div class="main">
      <div class="bg-about">
          <h2 class="text-title"> About us </h2>
      </div>
  </div>

  <div class="intro">
      <br> <h6 class="quote-italy"> "The public is more familiar with bad design than good design. It is, in effect, conditioned to prefer bad design, <br> because that is what it lives with. The new becomes threatening, the old reassuring." <br> <br> -- Paul Rand, graphic designer</h6>
      <br> 
      <h2 style="padding-top: 30px;"> What is the most important goal for a graphic designer? </h2> <br>
      <p> Perhaps the most important objective for a graphic designer is to meet deadlines established by the client. This is especially important for graphic designers working on newsletters, magazines, newspapers and other time-sensitive projects. 
      The ultimate goal of Design is to give you time. Look at the objects around you. When you trace back every (well designed) object and disassemble it to various fragments of functionality and effects it has, you will always find fragments labeled “I save time for you”. A lot of things cause time saving.
      </p>
      <p> Graphic design is art with a purpose. It involves a creative and systematic plan to solve a problem or achieve certain objectives, with the use of images, symbols or even words. It is visual communication and the aesthetic expression of concepts and ideas using various graphic elements and tools. </p>
      <p> Our goal is to shine any solution in the kind of design which can help people to bring their best creativity to the world and accepting the massive challenge of designing in around the world</p>
  </div>

    <footer>
      <div class="footer-title"> Halcyon.inc | Copyright 2021, All Rights Reserved. </div>
  </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>
