<!DOCTYPE html>
<html lang="ja">
    <head>
        <title> Welcome! </title>
        <style>


            body {
                margin: 0;
                padding: 0;
            }
            .image-class {
                height: 330px;
                width: 490px;
                padding-left: 10px;
                object-fit: cover;
                transition: 0.5s;
            }

            .image-class:hover {
                background-color: #420C49;
                transition: 0.5s;
            }
            
            .tr-width1 {
                width: 70%;
                float: left;
            }

            .tr-width2 {
                width: 20%;
                float: right;
            }

            .layout-start {
                background-color: #420C49;
                padding: 100px 50px;
                left: 30%;
                transition: 0.3s;
            }

            .layout-start:hover {
                background-color: #F3900F;
                transition: 0.3s;
                padding: 200px 50px;
                font-size: 20px;
            }

            .click-into {
                color: white;
                text-decoration: none;
                top: 50%;
            }

            table {
                width: 100%;
            }
        </style>
    </head>

    <body>
        <table>
            <tr class="tr-width1">
                <th> <img src="https://img.freepik.com/free-vector/graphic-design-geometric-wallpaper_52683-34399.jpg?size=626&ext=jpg" class="image-class"> </th>
                <th> <img src="https://s3.eu-west-2.amazonaws.com/ubisend.website/assets/blog/chatbot_design_patterns.jpg" class="image-class"> </th>
            </tr> <br> <tr class="tr-width1">
                <th> <img src="https://www.vippng.com/png/detail/541-5418226_best-graphic-logo-and-brand-design-in-ahmedabad.png" class="image-class"> </th>
                <th> <img src="https://hbr.org/resources/images/article_assets/2021/08/Aug21_11_864123306.jpg" class="image-class"> </th>
            </tr>
            
            <tr class="tr-width2"> 
                <th> <a href="Welcome/login" class="click-into layout-start">  Get start!  </a> </th>  
            </tr>
        </table>


    </body>
</html>