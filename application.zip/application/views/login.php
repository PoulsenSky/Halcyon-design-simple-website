<!DOCTYPE html>
<html>
    <head>
         <meta charset="UTF-8"> </meta>
        <title> Login </title>
        <style> 

            @import url(//db.onlinewebfonts.com/c/605c1c612570275f24508913462da771?family=Radikal);

            body {
                padding: 0;
                margin: 0;
                font-family: 'RadikalW03-Regular';
                text-align: center;
                transition: 0.5s;
                background-image: url('https://api.nomadstudio.com/images/_1200x630_crop_center-center_82_none/WEBSITE_PROJECT_TILES_PL-169.jpg?mtime=1593605778');
                background-repeat: no-repeat;
                background-attachment: fixed;
                background-size: cover;
            }

            .card {
                box-shadow: 2px 2px 2px 1px rgba(0, 0, 0, 0.2);
                border-radius:30px;
                background-color: white;
                border: 0;
                padding: 5px;
                left: 38%;
                top: 5%;
                width: 20%;
                position: relative;
                transition: 0.3s;
            }

            .card:hover {
                background-image: url('https://resources.premierleague.com/photos/2020/12/02/ca403c92-db70-48ac-91e2-0f2f18277133/PageHeader_RainbowLaces.png?width=1600&height=600');
                transition: 0.3s;
                color: white;
            }

            form {
                width: 20%;
                position: relative;
                background-color: #F3900F;
                color: #420C49;
                transition: 0.3s;
                left: 36%;
                margin: 30px;
                padding: 10px;
                border: 0;
                border-radius: 40px;
                box-shadow: 5px 5px 5px 1px rgba(0, 0, 0, 0.2);
            }

            form > input {
                border: 0px solid;
                border-radius: 10px;
                margin: 10px;
                padding: 10px;
            }

            form > input:active {
                border: 0px solid;
                border-radius: 10px;
            }

            form > button {
                border: 0px solid;
                border-radius: 10px;
                margin: 10px;
                padding: 10px;
                transition: 0.3s;
            }

            form > img {
                width:150px;
                margin: 10px;
            }
            form > button:hover {
                color: #420C49;
                background-color: #F3900F;
                transition: 0.3;
            } 

            form:hover {
                transition: 0.3s;
                box-shadow: 5px 5px 5px 1px rgba(0, 0, 0, 0.2);
                color: white;
                background-color: #420C49;
                width: 40%;
                left: 26%;
            }

            a {
              color: white;
            }

            a:link {
                
            }

            a:hover {
                color: #F3900F;
            }

            @media (max-width: 800px) {

              body {
                width: 100%;
              }
                form {
                  width: 50%;
                }
            }

            /* ________________________________  */
            .footer-title {
              background-color: #420C49;
              padding: 20px;
              color: white;
              bottom: 0;
              left: 0;
              right: 0;
              position: absolute;
            }
        </style>
    </head>
    <body>
<!--
  (HINT: is not being used)
        <div class="card">
        <h5> Welcome to the Dashboard! <br> Get your first introduction here! </h5>
        </div> -->
            
        <form method="POST" action="" id="login" name="login"> 
            <img src="<?= BASEURL;?>/assets/img/icon.png"> <br>
            <h2> Login </h2>
            <label for="username"> Username </label> <br>
            <input type="text" name="username" id="username" placeholder="Name here"> <br>
            <label for="password"> Password </label> <br>
            <input type="password" name="password" id="password" placeholder="Password here"> <br>
            <button type="submit" name="submit" id="submit"> Submit </button>
            <br>
            <p> Haven't make an account yet? Try to create your new one here! <a href="register"> >> </a> </p>
        </form>

        <footer>
            <div class="footer-title"> Halcyon.inc | Copyright 2021, All Rights Reserved. </div>
        </footer>
    </body>
</html>