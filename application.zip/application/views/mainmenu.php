<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Main Menu </title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
    <style>
      .paddingin {
        padding-bottom: 10px;
        padding-top: -30px;
      }

      .bg-about {
        background: url('https://www.designerd.com.br/wp-content/uploads/2020/03/espaco-branco-design-importancia.jpg');
        background: opacity(4) !important;
        height: 600px;
        width: 100%;
        object-fit: cover;
        margin: -20px -15px;
        padding: 0;
        background-size: cover;
        background-repeat: no-repeat;
      }

      .maintop {
        padding: 60px 0 0 15px;
      }

      .message {
        padding-top: 60px;
      }

      .text-title {
        text-align: left;
        color: black;
        font-family: 'RadikalW03-Bold';
        padding-top: 40px;
        padding-left: 50px;
        font-size: 60px;
      }

      .icon {
        padding-left: 50px;
        padding-top: 10px;
      }

      .icon img{
        height: 40px;
        padding-right: 20px;
        transition: 0.4s;
      }

      .icon img:hover {
        height: 50px;
        transition: 0.4s;
      }

      .icon a {
        text-decoration: none;
      }

      .quote-words {
        text-align: right;
        padding-right: 10px;
        float: right;
      }

      .bottomit {
        padding-top: 70px;
      }

      .topit {
        padding-top: 40px;
      }

      .hei1 {
        object-fit: cover;
        height: 350px;
        width: 350px;
        padding: 5px;
        background-size: cover;
        background-repeat: no-repeat;
        transition: 0.7s;
      }

      .hei1:hover {
        height: 320px;
        width: 320px;
        transition: 0.7s;
      }

    </style>
  </head>
  <body>
    <header>
      <div class="container">
        <div class="header-left">
          <a href="mainmenu"> <img class="logo" src="../assets/img/icon.png" href="mainmenu"> </a>
        </div>
        <!-- Add a menu icon here -->
  
        <div class="header-right">
          <a href="designmenu">What's new?</a>
          <a href="about"> About us </a>
          <a href="#designtoday">Current design</a>
          <a href="comment"> Feedback</a>
          <a href="logout" class="logout">Log out</a>
        </div>
      </div>
    </header>
  

  <div class="main">
    <table class="main-menu-table">
      <tr>
        <th>     
          <div id="carouselExampleControls" class="carousel slide width-carousel" data-ride="carousel">
          <div class="carousel-inner">
            <div class="carousel-item active">
              <img class="d-block w-100" src="https://wallpaperaccess.com/full/683408.jpg" alt="First slide">
            </div>
            <div class="carousel-item">
              <img class="d-block w-100" src="https://wallpaperaccess.com/full/683493.png" alt="Second slide">
            </div>
            <div class="carousel-item">
              <img class="d-block w-100" src="https://wallpaperaccess.com/full/498475.jpg" alt="Third slide">
            </div>
          </div>
          <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
          </a>
        </div> </th>
        <th> 
          <h1> Welcome to Halcyon House </h1>
          <p> A house for all designer around the world who wants to express their creativity in here and give a good effort to modernize the Environment with a minimalist style. Friendly are welcome!</p>

        </th>
      </tr>
    </table>
  </div>
    

  <div class="topit container2">
      <table>
        <tr>
          <th>
            <img src="https://img.freepik.com/free-photo/woman-designer-interior-working-workspace-concept_53876-48141.jpg?size=626&ext=jpg" class="hei1">
            <img src="https://images.ctfassets.net/40w0m41bmydz/1yfn4W4R4eggrHjiSn2IOx/311dbe300dd3a39b74ef578ae2142b0e/day-in-life-product-design_swillis_2x.jpg?w=1980&h=1485&fl=progressive&q=50&fm=jpg" class="hei1">
            <img src="http://frankdellafemina.com/wp-content/uploads/2020/09/interior-design.jpg" class="hei1">
            <img src="https://ecs7.tokopedia.net/blog-tokopedia-com/uploads/2018/09/Mengenal-Makna-Work-Life-Balance-Ala-Fauzan-Arief.jpg" class="hei1">
          </th>
          <th>
            <h1 style="font-family: RadikalW03-Bold;"> Our objectives </h1> <p> is to realising the environment of any conditional based from the part of vizualisation that can help <br> people to create any kind of innovation. </p>
            <br> <p> "The public is more familiar with bad design than good design. <br>
            It is, in effect, conditioned to prefer bad design, <br>
            because that is what it lives with. <br>The new becomes threatening, the old reassuring." <br>
        -- Paul Rand, graphic designer </p>  
          </th>
        </tr>
      </table>
  </div>


  <h1 style="text-align:center; font-family: RadikalW03-Bold; font-size: 50px;" class="subtitle-pad" id="designtoday"> Design of the Year </h1>
  <div class="card-group content">
    <div class="card">
      <img class="card-img-top" src="https://image.freepik.com/free-vector/minimalist-pink-social-media-instagram-feed-post-banner-template_74058-383.jpg" alt="Card image cap">
      <div class="card-body">
        <h5 class="card-title"> Carolina </h5>
        <p class="card-text"> Designed by: Freepik. <br> Including: minimalist abstract, concepted gradient colors such red, white, and black. </p>
        <p class="card-text"><small class="text-muted"> Rating 4.5/5 </small></p>
      </div>
    </div>
    <div class="card">
      <img class="card-img-top" src="https://graphicriver.img.customer.envatousercontent.com/files/312933458/grapchicriver.jpg?auto=compress%2Cformat&fit=crop&crop=top&w=590&h=590&s=8a7084bfa76f12b8a65166eee0a13bf4" alt="Card image cap">
      <div class="card-body">
        <h5 class="card-title"> Yellow Coffee </h5>
        <p class="card-text"> Designed by: Tierre Laurent. <br> Including: simple style inspired by mashup yellow and chocolate style, combined with a single variant </p>
        <p class="card-text"><small class="text-muted"> Rating 4/5 </small></p>
      </div>
    </div>
    <div class="card">
      <img class="card-img-top" src="https://nataliegisborne.com/wp-content/uploads/2-4.jpg" alt="Card image cap">
      <div class="card-body">
        <h5 class="card-title"> Outline World </h5>
        <p class="card-text"> Designed by: Dimitri Patrenko. <br> Including: no decoration + full concentration filter with a single semi-BnW style</p>
        <p class="card-text"><small class="text-muted"> Rating 4.2/5 </small></p>
      </div>
    </div>
    <div class="card">
      <img class="card-img-top" src="https://cf.shopee.co.id/file/ed450c9f61d71cc2a585e41c8b163e2f" alt="Card image cap">
      <div class="card-body">
        <h5 class="card-title"> Sebisu </h5>
        <p class="card-text"> Designed by: Shakirra Bentsu. <br> Including: collaboration between latte & chocolate style, provided with a single typography using traditional font </p>
        <p class="card-text"><small class="text-muted">Rating 4.1/5 </small></p>
      </div>
    </div>
  </div>
  <center>
  <div class=" paddingin">
  <a href="designmenu"> <button class="moreus"> More Design </button> </a> </center> </div> 
  <center> <hr> </center>
  
  <div class="maintop">
      <div class="bg-about">
          <h2 class="text-title"> "Create the new opportunity, <br> Show the new inspiration" </h2>
          <div class="icon">
            <p> Our objectives has been sponsored & supported by:</p>
            <a href="https://www.pinterest.com"> <img src="https://cdn.worldvectorlogo.com/logos/pinterest-1.svg"> </a>
            <a href="https://www.unsplash.com"> <img src="https://cdn4.iconfinder.com/data/icons/logos-brands-5/24/unsplash-512.png"> </a>
            <a href="https://www.deviantart.com/"> <img src="https://icons-for-free.com/iconfiles/png/512/circle+deviantart+round+icon+icon-1320190501515997248.png"> </a>
            <a href="https://www.behance.net/"> <img src="https://1000logos.net/wp-content/uploads/2020/11/Behance-logo.png"> </a>
          </div> <br> <br>
          <div class="quote-words">
            <p> "A place for all designer and  <br> beginner to impress everyone on <br> creating  their best for useful things. "</p>
            <h5 style="font-style: italic;"> -Diana Miller </h5>
          </div>
      </div>
    </div>

  <div class="message">
    <p> Want to join with us? Grab your email here for re-confirmation and participate with Halcyon Community for free! </p>
    <p> Unlimited Quota for Newcomer & Guaranteed steps to become the Professional Graphic Designer! </p> <br>
    <a href="subscribe"> <button class="join-us"> Click here! </button> </a>
  </div>
    <footer>
      <div class="footer-title"> Halcyon.inc | Copyright 2021, All Rights Reserved. </div>
  </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>
