<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function index()
	{
		$this->load->view('Welcome.php');
	}

	function daftar($data)
    {
         $this->db->insert('user',$data);
    }
	
	function komen($data)
    {
         $this->db->insert('comment',$data);
    }

	function subs($data)
    {
         $this->db->insert('subscribe',$data);
    }
	
	public function mainmenu() {
		$this->load->view('mainmenu.php');
	}

	public function about() {
		$this->load->view('about.php');
	}

	public function designmenu() {
		$this->load->view('designmenu.php');
	}

	public function login() {
		$this->load->view('login.php');
		
		if($this->input->post()) {
		$username = $this->input->post('username');
		$password = $this->input->post('password');

		$this->load->model('user');
		$result = $this->user->get_user_info($username);
		
		if($username == null) {
			if($password == null) {
				echo '<script language="javascript"> alert("Your data is empty, please input to login") </script>';
				}
			} else {
		}	if(count($result) > 0) {
			$password = md5($password);
			if($password != $result[0]['password']) {
				echo '<script language="javascript"> alert("You input the wrong password. Try again...") </script>';
			} else {
				echo "<script type='text/javascript'> alert('Welcome to Halcyon!');</script>";
				header("Location:mainmenu");
			}
				}	 else {
					$error = true;	
			}
		}
	}


	public function register() {
		$this->load->view('register.php');

		if($this->input->post()) {
			$this->form_validation->set_rules('email', 'email','required');
			$this->form_validation->set_rules('username', 'username','required');
			$this->form_validation->set_rules('club','club');
			$this->form_validation->set_rules('password','password','required');
			$this->form_validation->set_rules('favplayer ','favplayer');
	 
				$data['email']   =    $this->input->post('email');
				$data['username'] =    $this->input->post('username');
				$data['club']  =    $this->input->post('club');
				$data['favplayer']  =    $this->input->post('favplayer');
				$data['password'] =    md5($this->input->post('password'));

				if($data['username'] == null && $data['email'] == null && $data['password'] == null ) {
					$data['username'] = false;
					$data['email'] = false;
					$data['password'] = false;
					echo "<script type='text/javascript'> alert('Please input your missed data!');</script>";
					if($data['password'] == null) {
						$data['password'] = false;
						echo "<script type='text/javascript'> alert('Please input your correct password!');</script>";
					}
				} else {
					$this->daftar($data);
					echo "<script type='text/javascript'> alert('You have registered your new account!');</script>";
				}
		}
	}


	public function subscribe() {
		$this->load->view('subscribe.php');

		if($this->input->post()) {
			$this->form_validation->set_rules('email', 'email','required');

			$data['email']  =  $this->input->post('email');
			if($data['email'] === null) {
				$data['email'] = false;
				echo "<script type='text/javascript'> alert('You input the wrong data, please try again.');</script>"; 
			} else {
				$this->subs($data);
				echo "<script type='text/javascript'> alert('Your email has been successfully sent! We'll quickly inform you about the validation.');</script>";
			}
		}
	}

	public function comment() {
		$this->load->view('comment.php');

		if($this->input->post()) {
			$this->form_validation->set_rules('username', 'username','required');
			$this->form_validation->set_rules('feedback','feedback', 'required');
			$this->form_validation->set_rules('rating ','rating');
	 
				$data['username'] =    $this->input->post('username');
				$data['feedback']  =    $this->input->post('feedback');
				$data['rating']  =    $this->input->post('rating');

				if($data['username'] == null) {
					$data['username'] = false;
					echo "<script type='text/javascript'> alert('Please input the username!');</script>"; 
				} else if($data['feedback'] == null) {
					$data['feedback'] = false;
					echo "<script type='text/javascript'> alert('Please input the feedback!');</script>"; 
				} else {
					$this->komen($data);
					echo "<script type='text/javascript'> alert('Data has been successfully added!');</script>";
				}
				
		}
	}

	public function logout() {

		$this->session->sess_destroy();
		echo '<script> alert("You have been logged out") </script>';
		header("Location:login");
	}
}